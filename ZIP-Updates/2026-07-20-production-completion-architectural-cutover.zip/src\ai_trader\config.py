from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from .models import AutoTradeConfig, GuardrailConfig


def _bool_env(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _float_env(name: str, default: float) -> float:
    value = os.getenv(name)
    return default if value is None else float(value)


def _int_env(name: str, default: int) -> int:
    value = os.getenv(name)
    return default if value is None else int(value)


def load_dotenv(path: Path = Path(".env")) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


@dataclass(frozen=True)
class Settings:
    alpaca_api_key: str | None
    alpaca_secret_key: str | None
    alpaca_paper_base_url: str
    alpaca_data_base_url: str
    openai_api_key: str | None
    openai_model: str
    db_path: Path
    output_dir: Path
    trading_log_path: Path
    guardrails: GuardrailConfig
    database_backend: str = "sqlite"
    database_url: str | None = None
    render_api_key: str | None = None
    render_service_id: str | None = None
    auto_trade: AutoTradeConfig = field(default_factory=AutoTradeConfig)
    research_scheduler_enabled: bool = False
    research_scheduler_interval_minutes: int = 60
    research_scheduler_limit: int = 30
    auto_execution_interval_seconds: int = 60
    worker_research_enabled: bool = True
    production_snapshot_interval_seconds: int = 300
    worker_heartbeat_interval_seconds: int = 30
    worker_job_timeout_seconds: int = 180
    broker_poll_interval_seconds: int = 600
    process_role: str = "local"
    disable_api_background_workers: bool = False
    require_postgres_in_hosted: bool = True

    @property
    def has_alpaca_credentials(self) -> bool:
        return bool(self.alpaca_api_key and self.alpaca_secret_key)

    @property
    def uses_postgres(self) -> bool:
        return self.database_backend in {"postgres", "postgresql", "supabase"} and bool(self.database_url)

    @property
    def is_hosted_runtime(self) -> bool:
        return self.process_role in {"render", "api", "worker", "scheduled-job"} or bool(
            os.getenv("RENDER") or os.getenv("RENDER_SERVICE_ID") or os.getenv("RENDER_INSTANCE_ID")
        )

    def production_startup_errors(self, *, host: str | None = None) -> list[str]:
        hosted_host = bool(host and host not in {"127.0.0.1", "localhost", "::1"})
        if not (self.require_postgres_in_hosted and (self.is_hosted_runtime or hosted_host)):
            return []
        errors: list[str] = []
        if not self.uses_postgres:
            errors.append(
                "Hosted production requires AI_TRADER_DATABASE_BACKEND=postgres "
                "and DATABASE_URL or SUPABASE_DATABASE_URL. Refusing to silently use SQLite."
            )
        return errors


def load_settings() -> Settings:
    load_dotenv()
    return Settings(
        alpaca_api_key=os.getenv("ALPACA_API_KEY"),
        alpaca_secret_key=os.getenv("ALPACA_SECRET_KEY"),
        alpaca_paper_base_url=os.getenv("ALPACA_PAPER_BASE_URL", "https://paper-api.alpaca.markets"),
        alpaca_data_base_url=os.getenv("ALPACA_DATA_BASE_URL", "https://data.alpaca.markets"),
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        openai_model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
        db_path=Path(os.getenv("AI_TRADER_DB_PATH", "data/audit.sqlite3")),
        database_backend=os.getenv(
            "AI_TRADER_DATABASE_BACKEND",
            "postgres" if os.getenv("DATABASE_URL") else "sqlite",
        ).strip().lower(),
        database_url=os.getenv("DATABASE_URL") or os.getenv("SUPABASE_DATABASE_URL"),
        output_dir=Path(os.getenv("AI_TRADER_OUTPUT_DIR", "data")),
        trading_log_path=Path(os.getenv("AI_TRADER_TRADING_LOG_PATH", "governance/TRADING_LOG.md")),
        render_api_key=os.getenv("RENDER_API_KEY") or os.getenv("RENDER_API_TOKEN"),
        render_service_id=os.getenv("RENDER_SERVICE_ID"),
        guardrails=GuardrailConfig(
            max_risk_per_trade_pct=_float_env("MAX_RISK_PER_TRADE_PCT", 0.01),
            max_daily_loss_pct=_float_env("MAX_DAILY_LOSS_PCT", 0.03),
            max_open_positions=_int_env("MAX_OPEN_POSITIONS", 3),
            min_confidence_score=_float_env("MIN_CONFIDENCE_SCORE", 0.65),
            paper_trading_only=_bool_env("PAPER_TRADING_ONLY", True),
            allow_short_selling=_bool_env("ALLOW_SHORT_SELLING", False),
        ),
        auto_trade=AutoTradeConfig(
            enabled=_bool_env("AUTO_PAPER_TRADING", False),
            broker_enabled={
                "alpaca": _bool_env("ALPACA_AUTO_TRADING", _bool_env("AUTO_PAPER_TRADING", False)),
                "kraken": _bool_env("KRAKEN_AUTO_TRADING", _bool_env("KRAKEN_TRADING_ENABLED", False)),
                "coinbase": _bool_env("COINBASE_AUTO_TRADING", False),
                "binance": _bool_env("BINANCE_AUTO_TRADING", False),
                "interactive_brokers": _bool_env("IBKR_AUTO_TRADING", False),
            },
            min_confidence=_float_env("AUTO_TRADE_MIN_CONFIDENCE", 0.85),
            min_philosophy_fit=_float_env("AUTO_TRADE_MIN_PHILOSOPHY_FIT", 0.85),
            max_trade_amount=_float_env("MAX_AUTO_TRADE_AMOUNT", 25.0),
            default_stop_loss_pct=_float_env("DEFAULT_STOP_LOSS_PCT", 0.03),
            max_stop_loss_pct=_float_env("MAX_STOP_LOSS_PCT", 0.05),
            crypto_max_trade_amount=_float_env("CRYPTO_MAX_AUTO_TRADE_AMOUNT", 10.0),
            crypto_default_stop_loss_pct=_float_env("CRYPTO_DEFAULT_STOP_LOSS_PCT", 0.02),
            crypto_max_stop_loss_pct=_float_env("CRYPTO_MAX_STOP_LOSS_PCT", 0.05),
        ),
        research_scheduler_enabled=_bool_env("RESEARCH_SCHEDULER_ENABLED", False),
        research_scheduler_interval_minutes=_int_env("RESEARCH_SCHEDULER_INTERVAL_MINUTES", 60),
        research_scheduler_limit=_int_env("RESEARCH_SCHEDULER_LIMIT", 30),
        auto_execution_interval_seconds=_int_env("AUTO_EXECUTION_INTERVAL_SECONDS", 60),
        worker_research_enabled=_bool_env("AI_TRADER_WORKER_RESEARCH_ENABLED", True),
        production_snapshot_interval_seconds=_int_env("AI_TRADER_PRODUCTION_SNAPSHOT_INTERVAL_SECONDS", 300),
        worker_heartbeat_interval_seconds=_int_env("AI_TRADER_WORKER_HEARTBEAT_INTERVAL_SECONDS", 30),
        worker_job_timeout_seconds=_int_env("AI_TRADER_WORKER_JOB_TIMEOUT_SECONDS", 180),
        broker_poll_interval_seconds=_int_env("AI_TRADER_BROKER_POLL_INTERVAL_SECONDS", 600),
        process_role=os.getenv("AI_TRADER_PROCESS_ROLE", "local").strip().lower(),
        disable_api_background_workers=_bool_env("AI_TRADER_DISABLE_API_BACKGROUND_WORKERS", False),
        require_postgres_in_hosted=_bool_env("AI_TRADER_REQUIRE_POSTGRES_IN_HOSTED", True),
    )
